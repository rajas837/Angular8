# I18nDemo

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 7.0.1.

# Localization In Angular Using i18n Tools
In this article, we will learn how to make our Angular app available in different languages using i18n and localization. We will create an Angular application and configure it to serve the content in three different languages. We will also deploy our app to Google Firebase and see how localization works in real time.

